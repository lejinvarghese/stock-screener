import json
import os
import sys
here = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join(here, "./lib"))

import requests

TELEGRAM_TOKEN = '1033450588:AAGDdiz6N6_R9mzSceeuFvYmbcoIxA5wSGM'
TELEGRAM_ID = '902949428'
TELEGRAM_BASE_URL = "https://api.telegram.org/bot{}".format(TELEGRAM_TOKEN)

def lambda_handler(event, context):
    try:
        data = json.loads(event["body"])
        message = str(data["message"]["text"])
        chat_id = data["message"]["chat"]["id"]
        first_name = data["message"]["chat"]["first_name"]

        response = "Please /start, {}".format(first_name)

        if "start" in message:
            response = "Hello there, {}".format(first_name)

        data = {"text": response.encode("utf8"), "chat_id": chat_id}
        url = TELEGRAM_BASE_URL + "/sendMessage"
        requests.post(url, data)

    except Exception as e:
        print(e)

    return {"statusCode": 200}